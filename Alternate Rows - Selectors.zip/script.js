$("caption").css("background-color", "lightblue");
$("tr:even").css("background-color", "lightpink");
$("tr:odd").css("background-color", "lightblue");